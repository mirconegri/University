library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MSF is
  Port (
    -- Inserire qui le dichiarazioni delle porte:
    -- * Un ingresso di clock "clock"
    -- * Un ingresso di reset "reset"
    -- * Un ingresso di dato "L"
    -- * Una uscita "count_en". 
	-- * Una uscita "init".
	-- * Una uscita "ready".
    ...
  );
end MSF;

architecture Behavioral of ContatoreUni is
   
  -- Definizione il tipo per lo stato:
  type state_type is ...
  -- Definizione dei segnali di stato presente e futuro
  signal ...
  
begin

  -- Processo per la parte sequenziale. Ricordate la sensitivity list: il
  -- processo deve essere sensibile a tutti i segnali asincroni (quindi il
  -- clock ed il reset!)
  process ( ... ) begin
    -- Verificare se c'e' il reset. Ipotizziamo un reset attivo alto
    if ... then
      -- Inizializzare lo stato a quello iniziale
      ...
    elsif ... -- guardare se siamo al fronte del clock
      -- Aggiornare lo stato
      ...
    end if;
  end process;
  
  -- Processo per il calcolo dello stato futuro
  -- Il processo e' combinatorio. A cosa deve essere sensibile?
  process ( ... ) begin
    -- Ricordate che e' utile mettere un default per lo stato futuro. Questo
    -- rende il processo certamente combinatorio, e vi permette di gestire
    -- solo le condizioni alternative
    ...
    -- Ora vediamo cosa succede per ogni stato
    case ... is
      -- Una opzione per ogni stato
      when ... =>
        -- Guardare gli ingressi, e determinare lo stato futuro di conseguenza
        if ...
          ...
        end if;
      -- Come sopra per gli altri stati
      when ...
      when ...
      when ...
    end case;
  end process;

  -- Processo per il calcolo delle uscite.
  -- A cosa e' sensibile? Se e' una macchina di Moore? E se e' una macchina di
  -- Mealy?
  process ( ... ) begin
    -- Usate un default anche per le uscite. Rende tutto piu' semplice
    ...
    -- Aggiornare le uscite a seconda dello stato e (se di Mealy) degli
    -- ingressi
    ...
    
  end process;

end Behavioral;

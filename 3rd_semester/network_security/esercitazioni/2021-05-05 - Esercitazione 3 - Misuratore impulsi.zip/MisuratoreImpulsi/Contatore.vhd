library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity Contatore is
port (
    res, clock, count_en, init : in std_logic;
    y : buffer unsigned(3 downto 0)
);
end entity Contatore;

architecture behavioral of Contatore is

begin
    process (res, clock) is
        begin
        if (res = '1') then
            y <= (others => '0');
        elsif rising_edge(clock) then
            if init = '1' then
                y <= (others => '0');
            elsif count_en = '1' then
                y <= y + 1;  
            end if;      
        end if;        
    end process;
    
end architecture behavioral;

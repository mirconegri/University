library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all;

entity MisuratoreImpulsi is
  
  Port ( 
    -- Inserire qui le dichiarazioni delle porte:
    -- * Un ingresso di clock "clock"
    -- * Un ingresso di reset "reset"
    -- * Un ingresso di dato "L"
    -- * Una uscita c di 4 bit di tipo unsigned. 
    -- * Una uscita "ready".
    ...
  );
  
end MisuratoreImpulsi;

architecture Behavioral of MisuratoreImpulsi is

  -- Definizione dei segnali per collegamenti tra entita' (init, count_en)
  signal ...

begin
  -- Instanziamo le entita' e colleghiamo tutti i segnali
  MacchinaStati : entity work.MSF
  port map (
            -- Inserire i collegamenti tra porte e segnali:
            clock => clock,
            ...
            
  );
  
  Contatore : entity work.Contatore
  port map (
                    
  );

end Behavioral;


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all;

entity MisuratoreImpulsi_testbench is
--  Port ( );
end MisuratoreImpulsi_testbench;

architecture Behavioral of MisuratoreImpulsi_testbench is

  -- Definiamo il componente da utilizzare. Copiate la definizione di entita'
  -- che avete scritto, e cambiate "entity" in "component". Qui abbiamo
  -- ipotizzato dei nomi per i segnali, aggiustateli se ne avete usati di
  -- diversi
  component MisuratoreImpulsi is  
    Port ( 
          clock , L, reset: in std_logic;        
          c: buffer unsigned(3 downto 0); 
          ready: out std_logic
    );  
  end component;

  -- Definiamo i segnali interni. Nel testbench mettiamo tutti i segnali di
  -- ingresso e uscita del componente da testare
  signal clock : std_logic;
  signal reset : std_logic;
  signal L : std_logic;
  signal c : unsigned(3 downto 0);
  signal ready : std_logic;


begin
     -- Instanziamo il componente da testare. Colleghiamo tutti i segnali
    uut : MisuratoreImpulsi
    port map(
            clock => clock,
            L => L,
            c => c,
            ready => ready,
            reset => reset                    
        );
   -- Dobbiamo definire l'andamento di tutti gli input del componente. Gli
   -- output saranno invece generati dal componente stesso, non dobbiamo
   -- definirli qui, ma li vedremo in simulazione    
   -- Processo per la generazione del clock. Ipotizziamo un clock a 100 MHz
   process begin
      clock <= '0'; wait for 5 ns;
      clock <= '1'; wait for 5 ns;
   end process;

   -- Processo per la generazione del reset. Lo teniamo attivo (alto) per
   -- 100 ns, poi lo disattiviamo per sempre
   process begin
      reset <= '1'; wait for 100 ns;
      reset <= '0'; wait;
   end process;
   
   uut_test_proc : process
   begin
   
      L <= '0';
      -- Aspettiamo che finisca il reset
      wait for 125 ns;
      -- Attiviamo l'ingresso in modo da vedere diverse combinazioni
      
      L <= '1';
      wait for 30 ns;
      L <= '0';
      wait for 15 ns;
      L <= '1';
      wait for 50 ns;
      L <= '0';
      wait for 30 ns;
      L <= '1';
      wait for 100 ns;
      L <= '0';
      wait for 20 ns;
      
   wait;
   end process;

end Behavioral;
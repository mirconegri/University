library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity testbench is
--  Port ( );
end testbench;

architecture Behavioral of testbench is

  -- Definiamo il componente da utilizzare. Copiate la definizione di entita'
  -- che avete scritto, e cambiate "entity" in "component". Qui abbiamo
  -- ipotizzato dei nomi per i segnali, aggiustateli se ne avete usati di
  -- diversi
  component ContatoreUni is
    Port (
      clock : in std_logic; 
      reset : in std_logic;
      L : in std_logic;
      Dout : out std_logic_vector( 1 downto 0 )
    );
  end component;

  -- Definiamo i segnali interni. Nel testbench mettiamo tutti i segnali di
  -- ingresso e uscita del componente da testare
  signal clock, reset : std_logic;
  signal L : std_logic;
  signal Dout : std_logic_vector( 1 downto 0 );

begin

   -- Instanziamo il componente da testare. Colleghiamo tutti i segnali
   uut : ContatoreUni port map (
      clock => clock,
      reset => reset,
      L => L,
      Dout => Dout
   );
   
   -- Dobbiamo definire l'andamento di tutti gli input del componente. Gli
   -- output saranno invece generati dal componente stesso, non dobbiamo
   -- definirli qui, ma li vedremo in simulazione

   -- Processo per la generazione del clock. Ipotizziamo un clock a 100 MHz
   process begin
      clock <= '0'; wait for 5 ns;
      clock <= '1'; wait for 5 ns;
   end process;

   -- Processo per la generazione del reset. Lo teniamo attivo (basso) per
   -- 100 ns, poi lo disattiviamo per sempre
   process begin
      reset <= '0'; wait for 100 ns;
      reset <= '1'; wait;
   end process;
   
   -- Processo per la generazione del segnale di input
   uut_test_proc : process begin
      L <= '0';
      -- Aspettiamo che finisca il reset
      wait for 125 ns;
      -- Attiviamo l'ingresso in modo da vedere diverse combinazioni
      L <= '1';
      wait for 10 ns;
      L <= '0';
      wait for 10 ns;
      L <= '1';
      wait for 20 ns;
      L <= '0';
      wait for 30 ns;
     wait;
   end process;

end Behavioral;

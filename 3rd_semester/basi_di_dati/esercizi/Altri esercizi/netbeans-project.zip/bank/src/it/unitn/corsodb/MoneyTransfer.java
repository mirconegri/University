package it.unitn.corsodb;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MoneyTransfer {

    private static final String DB_DRIVER = "org.postgresql.Driver";
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/corsodb";
    private static final String DB_USERNAME = "studente";
    private static final String DB_PASSWORD = "studente";

    public static void main(final String[] args) {

        try {
            Class.forName(DB_DRIVER);
            final Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME,
                    DB_PASSWORD);

            try {
                System.out.println("Benvenuto nel sistema BonificiOnline(c) di Banca Cayman.");
                final String username = login(connection);

                final int sourceAccount = selectAccount(connection, username);
                final String targetUsername = selectCustomer(connection);
                final int targetAccount = selectAccount(connection, targetUsername);
                final int transferAmount = chooseAmount(connection, sourceAccount);

                transfer(connection, sourceAccount, targetAccount, transferAmount);

                System.out.println("Operazione terminata.\n\n"
                        + "Si ringrazia per aver usato il sistema.\nAdesso sei più povero di "
                        + transferAmount + "€.");
            } finally {
                connection.close();
            }
        } catch (final Throwable ex) {
            System.out.println("Errore di sistema (" + ex.getMessage() + ").\n\n"
                    + "Operazione annullata.\nBanca Cayman si scusa per il disagio.");
        }
    }

    private static String login(final Connection connection) throws Throwable {

        while (true) {
            final String username = askString("\nImmettere username");
            final String password = askString("Immettere password");

            final PreparedStatement stmt = connection.prepareStatement("SELECT name, surname FROM bank.customer WHERE username = ? AND password = ?");
            try {
                stmt.setString(1, username);
                stmt.setString(2, password);

                final ResultSet rs = stmt.executeQuery();
                try {
                    if (rs.next()) {
                        final String name = rs.getString(1);
                        final String surname = rs.getString(2);
                        System.out.println("Benvenuto " + name + " " + surname);
                        return username;
                    }
                } finally {
                    rs.close();
                }
            } finally {
                stmt.close();
            }
        }
    }

    private static int selectAccount(final Connection connection, final String username)
            throws Throwable {

        final List<Integer> accounts = new ArrayList<Integer>();
        final PreparedStatement stmt = connection.prepareStatement("SELECT number FROM bank.account WHERE customer = ?");
        try {
            stmt.setString(1, username);

            final ResultSet rs = stmt.executeQuery();
            try {
                while (rs.next()) {
                    accounts.add(rs.getInt(1));
                }
            } finally {
                rs.close();
            }
        } finally {
            stmt.close();
        }

        System.out.println("\nConti corrente disponibili per " + username + ":");
        for (int i = 0; i < accounts.size(); ++i) {
            System.out.println("(" + (i + 1) + ") " + accounts.get(i));
        }

        final int option = askNumber("Selezionare conto", 1, accounts.size());
        return accounts.get(option - 1);
    }

    private static String selectCustomer(final Connection connection) throws Throwable {

        while (true) {
            final String name = askString("\nImmettere nome beneficiario");
            final String surname = askString("Immettere cognome beneficiario");

            final List<String> usernames = new ArrayList<String>();
            final PreparedStatement stmt = connection.prepareStatement("SELECT username FROM bank.customer WHERE name = ? AND surname = ?");
            try {
                stmt.setString(1, name);
                stmt.setString(2, surname);

                final ResultSet rs = stmt.executeQuery();
                try {
                    while (rs.next()) {
                        usernames.add(rs.getString(1));
                    }
                } finally {
                    rs.close();
                }
            } finally {
                stmt.close();
            }

            if (usernames.isEmpty()) {
                System.out.println("Nessun cliente corrisponde a nome e cognome immessi.");
            } else {
                System.out.println("I seguenti clienti corrispondono a nome e cognome immessi:");
                for (int i = 0; i < usernames.size(); ++i) {
                    System.out.println("(" + (i + 1) + ") " + usernames.get(i));
                }

                final int option = askNumber("Selezionare cliente", 1, usernames.size());
                return usernames.get(option - 1);
            }
        }
    }

    private static int chooseAmount(final Connection connection, final int sourceAccount)
            throws Throwable {

        int maxAmount;
        final PreparedStatement stmt = connection.prepareStatement("SELECT amount FROM bank.account WHERE number = ?");
        try {
            stmt.setInt(1, sourceAccount);

            final ResultSet rs = stmt.executeQuery();
            try {
                rs.next();
                maxAmount = rs.getInt(1);
            } finally {
                rs.close();
            }
        } finally {
            stmt.close();
        }

        System.out.println("\nDisponibilità su conto corrente " + sourceAccount + ": " + maxAmount);

        final int amount = askNumber("Immettere importo bonifico", 1, maxAmount);
        return amount;
    }

    private static void transfer(final Connection connection, final int sourceAccount,
            final int targetAccount, final int amount) throws Throwable {

        connection.setAutoCommit(false);
        try {
            final PreparedStatement stmt = connection.prepareStatement("UPDATE bank.account SET amount = amount + ? WHERE number = ?");
            try {
                stmt.setInt(1, -amount);
                stmt.setInt(2, sourceAccount);
                stmt.executeUpdate();

                stmt.setInt(1, amount);
                stmt.setInt(2, targetAccount);
                stmt.executeUpdate();
            } finally {
                stmt.close();
            }

            final PreparedStatement stmt2 = connection.prepareStatement("INSERT INTO bank.transfer (source, target, amount, date) "
                    + "VALUES (?, ?, ?, CURRENT_DATE)");
            try {
                stmt2.setInt(1, sourceAccount);
                stmt2.setInt(2, targetAccount);
                stmt2.setInt(3, amount);
                stmt2.executeUpdate();
            } finally {
                stmt2.close();
            }

            connection.commit();

        } catch (final Throwable ex) {
            connection.rollback();
            ex.printStackTrace();

        } finally {
            connection.setAutoCommit(true);
        }
    }

    private static String askString(final String question) throws IOException {

        System.out.print(question + ": ");
        final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        return reader.readLine();
    }

    private static int askNumber(final String question, final int min, final int max)
            throws IOException {

        int option = 0;
        while (option < min || option > max) {
            try {
                option = Integer.parseInt(askString(question + " (" + min + "-" + max + ") "));
            } catch (final NumberFormatException ex) {
                System.out.println("(input non valido)");
            }
        }
        return option;
    }
}

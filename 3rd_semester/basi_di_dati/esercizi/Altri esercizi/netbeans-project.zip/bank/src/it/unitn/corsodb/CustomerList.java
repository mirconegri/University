package it.unitn.corsodb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class CustomerList {

    private static final String DB_DRIVER = "org.postgresql.Driver";
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/corsodb";
    private static final String DB_USERNAME = "studente";
    private static final String DB_PASSWORD = "studente";

    public static void main(final String[] args) throws Throwable {

        Class.forName(DB_DRIVER);
        final Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

        try {
            final Statement stmt = connection.createStatement();
            try {
                final ResultSet rs = stmt.executeQuery("SELECT surname, name, number, amount "
                        + "FROM bank.customer c JOIN bank.account a ON c.username = a.customer "
                        + "ORDER BY surname, name, number");
                try {
                    System.out.println("STAMPA ELENCO CONTI CORRENTE\n\n"
                            + " Cognome            | Nome               | Conto    | Importo\n"
                            + "--------------------|--------------------|----------|----------");

                    while (rs.next()) {
                        final String surname = rs.getString(1);
                        final String name = rs.getString(2);
                        final int account = rs.getInt(3);
                        final int amount = rs.getInt(4);
                        System.out.println(String.format(" %-18s | %-18s | %8d | %8d", surname,
                                name, account, amount));
                    }
                } finally {
                    rs.close();
                }
            } finally {
                stmt.close();
            }
        } finally {
            connection.close();
        }
    }
}
